# Links:

[Lab Notebook](https://docs.google.com/document/d/1XFZcpVfbainTZLCiMnmNKBXzJQCoXJPSIG4jM3vJNDQ/edit)


[Presentation Slides](https://docs.google.com/presentation/d/12Wx0nKubivoAW4lI8ctMYu1qRpKs8bhXRG6NTwSRlj8/edit#slide=id.p)

**Data Sources:** 
* [crashes](https://data.cityofchicago.org/Transportation/Traffic-Crashes-Crashes/85ca-t3if)
* [vehicles](https://data.cityofchicago.org/Transportation/Traffic-Crashes-Vehicles/68nd-jvt3)
* [people](https://data.cityofchicago.org/Transportation/Traffic-Crashes-People/u6pd-qa9d)
